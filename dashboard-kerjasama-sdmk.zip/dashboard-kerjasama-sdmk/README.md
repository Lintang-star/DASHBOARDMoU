# 🏛️ Dashboard Kerja Sama SDMK

Dashboard Streamlit untuk PJ SDMK: memantau **MoU, PKS, Kesepakatan Bersama (KB)**, **praktik mahasiswa**, dan **penelitian**.

## Fitur
| Halaman | Fungsi |
|---|---|
| **Beranda** | KPI, daftar *Perlu perhatian* (otomatis), agenda 30 hari, grafik status, linimasa masa berlaku dokumen |
| **Agenda & Pengingat** | Semua tanggal penting (dokumen berakhir, praktik, penelitian, tenggat), unduh `.ics` ke Google Calendar/Outlook |
| **MoU · PKS · KB** | Daftar + filter + detail, tambah, ubah, hapus; status otomatis (Aktif / Segera Berakhir / Kedaluwarsa / Dalam Penyusunan / Dibatalkan); relasi PKS → MoU induk; checklist kelengkapan |
| **Praktik Mahasiswa** | Pencatatan institusi, prodi, jumlah mahasiswa, penempatan, pembimbing, checklist administrasi; otomatis mengecek *dasar kerja sama* masih berlaku |
| **Penelitian** | Alur izin (Diajukan → Disetujui), jadwal pengambilan data, kaji etik, penyerahan laporan hasil |
| **Catatan Monitoring** | Catatan hasil monitoring + tindak lanjut, PJ, tenggat, status (terlambat otomatis) |
| **Laporan, Impor & Ekspor** | Rekap per mitra, semua peringatan, ekspor Excel berformat, impor massal Excel/CSV (ada templat), kosongkan data contoh |

Pengaturan "batas Segera Berakhir" (30–365 hari) ada di sidebar.

## Struktur
```
app.py              # navigasi & titik masuk
core/               # config (skema, warna), store (CSV/Google Sheets), logic (status, peringatan), forms, crud, ui, export, demo
views/              # satu file per halaman
.streamlit/         # config.toml (tema) & secrets.toml.example
tests_smoke.py      # uji asap semua halaman
```

## 1. Coba di komputer
```bash
pip install -r requirements.txt
streamlit run app.py
```
Saat pertama jalan, data contoh (fiktif) otomatis dibuat di folder `data/`. Hapus lewat **Laporan → Kelola Data** sebelum memakai data asli.

## 2. Unggah ke GitHub
1. Buat repository baru di GitHub (boleh *private*).
2. Upload seluruh isi folder ini (atau `git init`, `git add .`, `git commit`, `git push`).
3. File `.gitignore` sudah menjaga `secrets.toml` dan `data/*.csv` agar tidak ikut terunggah.

## 3. Deploy ke Streamlit Community Cloud
1. Buka share.streamlit.io → **Create app** → pilih repository, branch `main`, file utama `app.py`.
2. Sebelum/sesudah deploy, isi **Settings → Secrets** (langkah 4).

## 4. Penyimpanan permanen: Google Sheets (WAJIB untuk data asli)
Disk Streamlit Cloud bersifat sementara; tanpa langkah ini data hilang saat aplikasi restart.
1. Buat Google Sheet kosong (mis. "Data Kerja Sama SDMK").
2. Di Google Cloud Console: buat project → aktifkan **Google Sheets API** dan **Google Drive API** → *IAM & Admin → Service Accounts* → buat akun → *Keys → Add key → JSON*.
3. Buka Google Sheet → **Share** → tambahkan `client_email` dari file JSON sebagai **Editor**.
4. Di Streamlit Cloud → Secrets, tempel isi `.streamlit/secrets.toml.example` dan ganti dengan data Anda (URL sheet + isi JSON + `app_password`).
5. Reboot app. Tab/sheet `kerjasama`, `praktik`, `penelitian`, `catatan` dibuat otomatis. Footer sidebar akan menampilkan *Penyimpanan: Google Sheets*.

## 5. Keamanan & catatan
- Isi `app_password` agar dashboard tidak terbuka untuk umum. Untuk kontrol per-pengguna, atur repo *private* dan batasi akses aplikasi di pengaturan Sharing Streamlit.
- Jangan simpan data pribadi sensitif (mis. NIK) di sheet.
- Penulisan memakai metode "baca terbaru → ubah → tulis ulang"; bila dua orang menyimpan pada detik yang sama, yang terakhir menang. Unduh Excel berkala sebagai cadangan.
- Data di cache 45 detik; tombol **Muat ulang data** memaksa pembaruan.

## Menyesuaikan
- **Warna**: `core/config.py` (`COLORS`) dan `.streamlit/config.toml`.
- **Kolom/isian/pilihan**: ubah daftar `F(...)` di `core/config.py`; form, tabel, impor, dan ekspor ikut menyesuaikan. (Jika di Google Sheets, kolom baru otomatis kosong untuk baris lama.)
- **Aturan peringatan**: `build_alerts()` di `core/logic.py`.
- **Nama aplikasi**: `APP_NAME` di `core/config.py`.

## Palet
Navy `#0F2F4F` · Teal `#14808A` · Emas `#C8A03C` · Hijau `#2E7D5B` · Amber `#E0A030` · Merah `#B23A48` · Latar `#F5F7FA`
