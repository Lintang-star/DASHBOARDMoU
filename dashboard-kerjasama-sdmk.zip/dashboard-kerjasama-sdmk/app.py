"""Titik masuk aplikasi. Jalankan: streamlit run app.py"""
import streamlit as st

from core import config as C
from core import ui

st.set_page_config(page_title=C.APP_NAME, page_icon="🏛️", layout="wide", initial_sidebar_state="expanded")
ui.setup_global()

pages = {
    "Utama": [
        st.Page("views/beranda.py", title="Beranda", icon="📊", default=True),
        st.Page("views/agenda.py", title="Agenda & Pengingat", icon="🗓️"),
    ],
    "Pengelolaan Data": [
        st.Page("views/kerjasama.py", title="MoU · PKS · KB", icon="📑"),
        st.Page("views/praktik.py", title="Praktik Mahasiswa", icon="🎓"),
        st.Page("views/penelitian.py", title="Penelitian", icon="🔬"),
        st.Page("views/catatan.py", title="Catatan Monitoring", icon="📝"),
    ],
    "Laporan": [
        st.Page("views/laporan.py", title="Laporan, Impor & Ekspor", icon="📤"),
    ],
}
nav = st.navigation(pages)
ui.sidebar_settings()
nav.run()
