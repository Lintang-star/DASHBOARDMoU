"""Konfigurasi pusat: palet warna, skema data, dan opsi isian."""
from __future__ import annotations

from dataclasses import dataclass, field

APP_NAME = "Dashboard Kerja Sama SDMK"
APP_TAGLINE = "Pemantauan MoU, PKS, Kesepakatan Bersama, Praktik Mahasiswa & Penelitian"
TIMEZONE = "Asia/Jakarta"
DEFAULT_THRESHOLD_DAYS = 90  # batas "Segera Berakhir"

# ---------------------------------------------------------------- PALET WARNA
COLORS = dict(
    navy="#0F2F4F", teal="#14808A", gold="#C8A03C",
    bg="#F5F7FA", card="#FFFFFF", text="#1E2A38", muted="#6B7A8C", border="#DDE3EA",
    green="#2E7D5B", amber="#E0A030", red="#B23A48", blue="#4F7CAC", grey="#8A94A0", violet="#7B6FA8",
)

STATUS_COLOR = {
    # kerja sama
    "Aktif": COLORS["green"], "Segera Berakhir": COLORS["amber"], "Kedaluwarsa": COLORS["red"],
    "Dalam Penyusunan": COLORS["blue"], "Dibatalkan": COLORS["grey"], "Belum Berlaku": COLORS["violet"],
    # praktik
    "Dijadwalkan": COLORS["blue"], "Berlangsung": COLORS["green"], "Selesai": COLORS["grey"],
    # penelitian
    "Proses Izin": COLORS["amber"], "Berjalan": COLORS["green"], "Ditolak": COLORS["red"],
    "Disetujui": COLORS["teal"], "Selesai - Menunggu Laporan": COLORS["gold"],
    # catatan
    "Belum Dimulai": COLORS["blue"], "Proses": COLORS["teal"], "Terlambat": COLORS["red"], "Tidak Perlu": COLORS["grey"],
}
STATUS_ICON = {
    "Aktif": "🟢", "Segera Berakhir": "🟠", "Kedaluwarsa": "🔴", "Dalam Penyusunan": "🔵",
    "Dibatalkan": "⚫", "Belum Berlaku": "🟣", "Dijadwalkan": "🔵", "Berlangsung": "🟢", "Selesai": "⚪",
    "Proses Izin": "🟠", "Berjalan": "🟢", "Ditolak": "🔴", "Disetujui": "🟢",
    "Selesai - Menunggu Laporan": "🟡", "Belum Dimulai": "🔵", "Proses": "🟡",
    "Terlambat": "🔴", "Tidak Perlu": "⚪",
}
LEVEL_ICON = {"Tinggi": "🔴 Tinggi", "Sedang": "🟠 Sedang", "Info": "🔵 Info"}

# ---------------------------------------------------------------- SKEMA DATA
@dataclass
class F:
    """Satu kolom/isian. kind: text, area, select, select_new, date, date_opt, int, bool, url, ref"""
    key: str
    label: str
    kind: str = "text"
    options: list | None = None
    required: bool = False
    wide: bool = False
    help: str | None = None
    default: object = None
    ref: str | None = None          # 'kerjasama' | 'all'
    none_label: str = "belum ada"   # untuk date_opt
    default_none: bool = True       # date_opt: default tercentang "belum ada" saat data baru
    placeholder: str | None = None


@dataclass
class Entity:
    key: str
    title: str
    singular: str
    prefix: str
    fields: list[F]
    list_cols: list[str]
    filter_cols: list[str] = field(default_factory=list)
    sort: tuple[str, bool] = ("id", True)

    @property
    def ck_cols(self):
        return [f.key for f in self.fields if f.key.startswith("ck_")]


JENIS_KS = ["MoU", "PKS", "KB"]
JENIS_KS_FULL = {"MoU": "Memorandum of Understanding", "PKS": "Perjanjian Kerja Sama", "KB": "Kesepakatan Bersama"}
KATEGORI_MITRA = ["Perguruan Tinggi", "Fasilitas Pelayanan Kesehatan", "Instansi Pemerintah",
                  "Organisasi Profesi", "Swasta / Industri", "Lembaga Swadaya / Internasional", "Lainnya"]

KERJASAMA = Entity(
    key="kerjasama", title="Kerja Sama (MoU, PKS, KB)", singular="dokumen kerja sama", prefix="KS",
    fields=[
        F("jenis", "Jenis dokumen", "select", options=JENIS_KS, required=True,
          help="MoU = nota kesepahaman; PKS = perjanjian kerja sama teknis; KB = kesepakatan bersama"),
        F("nomor_dokumen", "Nomor dokumen (pihak kita)", required=True),
        F("nomor_mitra", "Nomor dokumen (pihak mitra)"),
        F("mitra", "Nama mitra", "select_new", required=True, help="Pilih dari daftar atau ketik mitra baru"),
        F("judul", "Judul / perihal", wide=True, required=True),
        F("kategori_mitra", "Kategori mitra", "select", options=KATEGORI_MITRA),
        F("induk_id", "Dokumen induk (mis. PKS di bawah MoU)", "ref", ref="kerjasama"),
        F("status_proses", "Status proses", "select", options=["Berlaku", "Dalam Penyusunan", "Dibatalkan"], default="Berlaku",
          help="Status 'Aktif/Segera Berakhir/Kedaluwarsa' dihitung otomatis dari tanggal"),
        F("pj_internal", "Penanggung jawab internal"),
        F("tanggal_ttd", "Tanggal penandatanganan", "date_opt", none_label="belum ditandatangani"),
        F("tanggal_mulai", "Tanggal mulai berlaku", "date", required=True),
        F("tanggal_berakhir", "Tanggal berakhir", "date_opt", none_label="tanpa batas waktu", default_none=False),
        F("kontak_mitra", "Kontak mitra (nama / telp / email)"),
        F("ruang_lingkup", "Ruang lingkup kerja sama", "area", wide=True),
        F("link_dokumen", "Tautan dokumen (Drive/PDF)", "url", wide=True, placeholder="https://..."),
        F("catatan", "Catatan", "area", wide=True),
        F("ck_ttd_lengkap", "Sudah ditandatangani kedua pihak"),
        F("ck_arsip", "Arsip dokumen tersimpan"),
        F("ck_evaluasi", "Evaluasi pelaksanaan dilakukan"),
        F("ck_perpanjangan", "Proses perpanjangan berjalan"),
    ],
    list_cols=["id", "jenis", "nomor_dokumen", "mitra", "judul", "tanggal_mulai", "tanggal_berakhir",
               "sisa_hari", "status", "kelengkapan", "pj_internal", "link_dokumen"],
    filter_cols=["jenis", "kategori_mitra", "mitra", "pj_internal"],
    sort=("tanggal_berakhir", True),
)
PRAKTIK = Entity(
    key="praktik", title="Praktik Mahasiswa", singular="praktik mahasiswa", prefix="PM",
    fields=[
        F("institusi", "Institusi asal", "select_new", required=True),
        F("prodi", "Program studi", required=True),
        F("jenjang", "Jenjang", "select", options=["D3", "D4 / Sarjana Terapan", "S1", "Profesi", "S2", "SMK", "Lainnya"], default="S1"),
        F("jenis_praktik", "Jenis kegiatan", "select",
          options=["PBL / Praktik Lapangan", "Magang", "Praktik Klinik", "Observasi / Kunjungan", "Pengambilan Data Awal", "Lainnya"]),
        F("unit_penempatan", "Unit / lokasi penempatan", required=True),
        F("jumlah_mahasiswa", "Jumlah mahasiswa", "int", default=1),
        F("tanggal_mulai", "Tanggal mulai", "date", required=True),
        F("tanggal_selesai", "Tanggal selesai", "date", required=True),
        F("kerjasama_id", "Dasar kerja sama (MoU/PKS/KB)", "ref", ref="kerjasama", wide=True),
        F("pembimbing_lapangan", "Pembimbing lapangan"),
        F("pembimbing_institusi", "Pembimbing institusi / dosen"),
        F("kontak", "Kontak (telp / email)"),
        F("dibatalkan", "Kegiatan dibatalkan", "bool"),
        F("link_dokumen", "Tautan berkas (surat, daftar nama)", "url", wide=True),
        F("catatan", "Catatan", "area", wide=True),
        F("ck_permohonan", "Surat permohonan diterima"),
        F("ck_balasan", "Surat balasan / persetujuan terbit"),
        F("ck_pembimbing", "Pembimbing lapangan ditetapkan"),
        F("ck_orientasi", "Orientasi dilaksanakan"),
        F("ck_evaluasi", "Penilaian / evaluasi dikirim"),
        F("ck_laporan", "Laporan akhir diterima"),
    ],
    list_cols=["id", "institusi", "prodi", "jenis_praktik", "unit_penempatan", "jumlah_mahasiswa",
               "tanggal_mulai", "tanggal_selesai", "status", "status_dasar", "kelengkapan", "pembimbing_lapangan"],
    filter_cols=["institusi", "jenjang", "jenis_praktik", "unit_penempatan"],
    sort=("tanggal_mulai", False),
)
PENELITIAN = Entity(
    key="penelitian", title="Penelitian", singular="penelitian", prefix="PN",
    fields=[
        F("judul", "Judul penelitian", wide=True, required=True),
        F("peneliti", "Nama peneliti", required=True),
        F("nim_nip", "NIM / NIP"),
        F("institusi", "Institusi asal", "select_new"),
        F("jenis", "Jenis penelitian", "select",
          options=["Skripsi", "Tesis", "Disertasi", "Penelitian Dosen", "Penelitian Lembaga / Mandiri", "Pengambilan Data Awal"]),
        F("metode", "Desain / metode", "select", options=["Kuantitatif", "Kualitatif", "Mixed Methods", "Studi Dokumen", "Lainnya"]),
        F("lokasi", "Lokasi / unit penelitian", required=True),
        F("kerjasama_id", "Dasar kerja sama (jika ada)", "ref", ref="kerjasama"),
        F("tanggal_pengajuan", "Tanggal pengajuan izin", "date_opt"),
        F("status_izin", "Status izin", "select", options=["Diajukan", "Diproses", "Disetujui", "Ditolak"], default="Diajukan"),
        F("nomor_surat_izin", "Nomor surat izin / rekomendasi"),
        F("tanggal_izin", "Tanggal surat izin terbit", "date_opt"),
        F("tanggal_mulai", "Tanggal mulai pengambilan data", "date_opt"),
        F("tanggal_selesai", "Tanggal selesai pengambilan data", "date_opt"),
        F("pembimbing_lapangan", "Pendamping / PJ di lokasi"),
        F("kontak", "Kontak (telp / email)"),
        F("link_dokumen", "Tautan berkas (proposal, izin)", "url", wide=True),
        F("catatan", "Catatan", "area", wide=True),
        F("ck_proposal", "Proposal diterima"),
        F("ck_etik", "Kaji etik (ethical clearance) tersedia"),
        F("ck_izin_unit", "Disposisi / izin unit lokasi"),
        F("ck_laporan_hasil", "Laporan hasil diserahkan"),
    ],
    list_cols=["id", "judul", "peneliti", "institusi", "jenis", "lokasi", "status_izin",
               "tanggal_mulai", "tanggal_selesai", "status", "kelengkapan"],
    filter_cols=["jenis", "institusi", "status_izin"],
    sort=("tanggal_pengajuan", False),
)

CATATAN = Entity(
    key="catatan", title="Catatan Monitoring & Tindak Lanjut", singular="catatan monitoring", prefix="CM",
    fields=[
        F("tanggal", "Tanggal catatan", "date", required=True),
        F("ref_id", "Terkait dengan", "ref", ref="all", help="Hubungkan catatan ke dokumen/kegiatan tertentu, atau biarkan 'Umum'"),
        F("ringkasan", "Ringkasan monitoring / hasil pembahasan", "area", wide=True, required=True),
        F("tindak_lanjut", "Tindak lanjut yang diperlukan", "area", wide=True),
        F("penanggung_jawab", "Penanggung jawab tindak lanjut"),
        F("tenggat", "Tenggat tindak lanjut", "date_opt", none_label="tanpa tenggat"),
        F("status_tl", "Status tindak lanjut", "select", options=["Belum Dimulai", "Proses", "Selesai", "Tidak Perlu"], default="Belum Dimulai"),
    ],
    list_cols=["id", "tanggal", "ref_id", "ringkasan", "tindak_lanjut", "penanggung_jawab", "tenggat", "sisa_hari", "status"],
    filter_cols=["penanggung_jawab", "jenis_record"],
    sort=("tanggal", False),
)

ENTITIES = {e.key: e for e in (KERJASAMA, PRAKTIK, PENELITIAN, CATATAN)}

# Isian ber-awalan ck_ (checklist) dan 'dibatalkan' adalah kotak centang
for _e in ENTITIES.values():
    for _f in _e.fields:
        if _f.key.startswith("ck_") or _f.key == "dibatalkan":
            _f.kind = "bool"

# Pengaturan tampilan kolom turunan (hasil perhitungan)
COMPUTED_LABELS = {
    "sisa_hari": "Sisa Hari", "status": "Status", "kelengkapan": "Kelengkapan",
    "status_dasar": "Status Dasar KS", "jenis_record": "Jenis Terkait",
}
