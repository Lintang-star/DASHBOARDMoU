"""Halaman CRUD generik: Daftar (filter + detail), Tambah, Ubah/Hapus."""
from __future__ import annotations

import pandas as pd
import streamlit as st

from . import config as C
from . import forms, logic, store, ui


def _col_config(entity: C.Entity) -> dict:
    cfg: dict = {}
    fmap = {f.key: f for f in entity.fields}
    for k in entity.list_cols:
        if k in fmap:
            f = fmap[k]
            if f.kind in ("date", "date_opt"):
                cfg[k] = st.column_config.DateColumn(f.label, format="DD MMM YYYY")
            elif f.kind == "int":
                cfg[k] = st.column_config.NumberColumn(f.label, format="%d")
            elif f.kind == "url":
                cfg[k] = st.column_config.LinkColumn(f.label, display_text="Buka")
            elif f.kind == "bool":
                cfg[k] = st.column_config.CheckboxColumn(f.label)
            else:
                cfg[k] = st.column_config.TextColumn(f.label)
    cfg["id"] = st.column_config.TextColumn("ID", width="small")
    cfg["sisa_hari"] = st.column_config.NumberColumn("Sisa Hari", format="%d")
    cfg["status"] = st.column_config.TextColumn("Status")
    cfg["kelengkapan"] = st.column_config.ProgressColumn("Kelengkapan", min_value=0, max_value=100, format="%d%%")
    cfg["status_dasar"] = st.column_config.TextColumn("Status Dasar KS")
    cfg["jenis_record"] = st.column_config.TextColumn("Jenis Terkait")
    cfg["ref_id"] = st.column_config.TextColumn("Terkait")
    return cfg


def _detail(entity: C.Entity, row: pd.Series) -> None:
    st.markdown(f"##### Detail · {row['id']}")
    c1, c2 = st.columns(2)
    items = []
    for f in entity.fields:
        if f.kind == "bool":
            continue
        v = row[f.key]
        if f.kind in ("date", "date_opt"):
            v = v.strftime("%d %B %Y") if pd.notna(v) else "—"
        elif f.kind == "url":
            v = f"[Buka dokumen]({v})" if v else "—"
        elif f.kind == "ref":
            v = v or "—"
        else:
            v = str(v) if str(v).strip() else "—"
        items.append((f.label, v))
    half = (len(items) + 1) // 2
    for col, chunk in ((c1, items[:half]), (c2, items[half:])):
        with col:
            for lab, v in chunk:
                st.markdown(f"**{lab}**  \n{v}")
    if entity.ck_cols:
        st.markdown("**Kelengkapan**")
        st.markdown("  ".join(f"{'✅' if row[f.key] else '⬜'} {f.label}" for f in entity.fields if f.key.startswith("ck_")))
    st.caption(f"Status: {C.STATUS_ICON.get(row['status'], '')} {row['status']} · Terakhir diperbarui: {row['diperbarui'] or '—'}")


def _filters(entity: C.Entity, df: pd.DataFrame) -> pd.DataFrame:
    with st.expander("🔎 Cari & filter", expanded=True):
        c1, c2 = st.columns([2, 2])
        q = c1.text_input("Cari kata kunci", key=f"q_{entity.key}", placeholder="nomor, mitra, judul, nama…")
        sts = sorted(df["status"].unique())
        pick = c2.multiselect("Status", sts, key=f"st_{entity.key}")
        fmap = {f.key: f.label for f in entity.fields}
        fmap.update(C.COMPUTED_LABELS)
        cols = st.columns(max(len(entity.filter_cols), 1))
        extra = {}
        for c, k in zip(cols, entity.filter_cols):
            extra[k] = c.multiselect(fmap.get(k, k), sorted(x for x in df[k].unique() if str(x).strip()), key=f"f_{entity.key}_{k}")
    out = df
    if q:
        text = out.select_dtypes(include="object").astype(str).agg(" ".join, axis=1).str.lower()
        out = out[text.str.contains(q.lower(), regex=False)]
    if pick:
        out = out[out["status"].isin(pick)]
    for k, vals in extra.items():
        if vals:
            out = out[out[k].isin(vals)]
    return out


def run(key: str, thr: int) -> None:
    entity = C.ENTITIES[key]
    all_ = logic.enrich_all(store.load_all(), thr)
    df = all_[key]
    refs = logic.build_refs(all_)
    existing = {f.key: sorted(x for x in df[f.key].unique() if x) for f in entity.fields if f.kind == "select_new"}
    ctx = {"refs": refs, "existing": existing}

    t_list, t_add, t_edit = st.tabs(["📋 Daftar", "➕ Tambah", "✏️ Ubah / Hapus"])

    # ---------------- daftar
    with t_list:
        if df.empty:
            st.info(f"Belum ada data {entity.singular}. Tambahkan lewat tab **Tambah**.")
        else:
            counts = df["status"].value_counts()
            cols = st.columns(min(len(counts) + 1, 6))
            ui.kpi(cols[0], "Total", len(df), color=C.COLORS["navy"])
            for c, (s, n) in zip(cols[1:], counts.items()):
                ui.kpi(c, s, n, color=C.STATUS_COLOR.get(s, C.COLORS["teal"]))
            st.write("")
            view = _filters(entity, df)
            sk, asc = entity.sort
            view = view.sort_values(sk, ascending=asc, na_position="last")
            show = view[entity.list_cols].copy()
            show["status"] = show["status"].map(lambda s: f"{C.STATUS_ICON.get(s, '')} {s}")
            st.caption(f"Menampilkan {len(show)} dari {len(df)} data · klik satu baris untuk melihat detail")
            ev = st.dataframe(show, hide_index=True, width="stretch", column_config=_col_config(entity),
                              on_select="rerun", selection_mode="single-row", key=f"tbl_{key}")
            rows = ev.selection.rows if ev and ev.selection else []
            if rows:
                with st.container(border=True):
                    _detail(entity, view.iloc[rows[0]])

    # ---------------- tambah
    with t_add:
        with st.form(f"add_{key}", clear_on_submit=True):
            vals = forms.render_fields(entity.fields, None, f"add_{key}", ctx)
            ok = st.form_submit_button(f"💾 Simpan {entity.singular}", type="primary")
        if ok:
            errs = forms.validate(entity, vals)
            if errs:
                for e in errs:
                    st.error(e)
            else:
                rid = store.upsert(key, forms.to_row(vals))
                ui.flash(f"Data tersimpan dengan ID **{rid}**.")
                st.rerun()

    # ---------------- ubah / hapus
    with t_edit:
        if df.empty:
            st.info("Belum ada data untuk diubah.")
        else:
            sel = st.selectbox("Pilih data", df["id"].tolist(), key=f"sel_{key}",
                               format_func=lambda i: logic.label_of(key, df[df["id"] == i].iloc[0]))
            row = df[df["id"] == sel].iloc[0].to_dict()
            ctx_e = {**ctx, "exclude_id": sel}
            with st.form(f"edit_{key}_{sel}"):
                vals = forms.render_fields(entity.fields, row, f"e_{key}_{sel}", ctx_e)
                ok = st.form_submit_button("💾 Simpan perubahan", type="primary")
            if ok:
                errs = forms.validate(entity, vals)
                if errs:
                    for e in errs:
                        st.error(e)
                else:
                    r = forms.to_row(vals)
                    r["id"] = sel
                    store.upsert(key, r)
                    ui.flash(f"Perubahan **{sel}** tersimpan.")
                    st.rerun()
            with st.expander("🗑️ Hapus data ini"):
                st.warning("Penghapusan tidak dapat dibatalkan.")
                yakin = st.checkbox(f"Saya yakin ingin menghapus {sel}", key=f"del_ok_{key}_{sel}")
                if st.button("Hapus permanen", disabled=not yakin, key=f"del_{key}_{sel}"):
                    store.delete(key, sel)
                    ui.flash(f"{sel} dihapus.")
                    st.rerun()
