"""Data contoh (fiktif) agar dashboard langsung terisi saat pertama kali dijalankan lokal."""
from __future__ import annotations

import pandas as pd

from .logic import today


def _d(offset: int | None):
    return "" if offset is None else (today() + pd.Timedelta(days=offset)).strftime("%Y-%m-%d")


def _t(v: bool) -> str:
    return "TRUE" if v else "FALSE"


def generate(key: str) -> pd.DataFrame:
    return pd.DataFrame(globals()[f"_{key}"]())


def _kerjasama():
    base = dict(nomor_mitra="", kategori_mitra="Perguruan Tinggi", induk_id="", status_proses="Berlaku", pj_internal="Staf SDMK",
                kontak_mitra="", ruang_lingkup="", link_dokumen="", catatan="")
    data = [
        dict(jenis="MoU", nomor_dokumen="440/001/MoU/2024", mitra="Universitas Nusantara Sehat", judul="Kerja sama tridharma perguruan tinggi bidang kesehatan",
             tanggal_ttd=_d(-900), tanggal_mulai=_d(-900), tanggal_berakhir=_d(200), ck=(1, 1, 1, 0)),
        dict(jenis="PKS", nomor_dokumen="440/014/PKS/2025", mitra="Universitas Nusantara Sehat", judul="Pelaksanaan PBL dan praktik lapangan mahasiswa",
             induk_id="KS-0001", tanggal_ttd=_d(-400), tanggal_mulai=_d(-400), tanggal_berakhir=_d(45), ck=(1, 1, 0, 0)),
        dict(jenis="MoU", nomor_dokumen="440/007/MoU/2021", mitra="Politeknik Kesehatan Cendana", judul="Kerja sama pendidikan dan pelatihan tenaga kesehatan",
             tanggal_ttd=_d(-1500), tanggal_mulai=_d(-1500), tanggal_berakhir=_d(-20), ck=(1, 1, 0, 0)),
        dict(jenis="PKS", nomor_dokumen="440/021/PKS/2023", mitra="Politeknik Kesehatan Cendana", judul="Praktik klinik mahasiswa keperawatan",
             induk_id="KS-0003", tanggal_ttd=_d(-800), tanggal_mulai=_d(-800), tanggal_berakhir=_d(-60), ck=(1, 1, 1, 0)),
        dict(jenis="KB", nomor_dokumen="440/003/KB/2026", mitra="Institut Kesehatan Wijaya Kusuma", judul="Kesepakatan bersama penelitian dan magang",
             tanggal_ttd=_d(-100), tanggal_mulai=_d(-100), tanggal_berakhir=_d(630), ck=(1, 1, 0, 0)),
        dict(jenis="MoU", nomor_dokumen="(draf)", mitra="STIKes Bhakti Husada", judul="Rencana kerja sama pengembangan SDM kesehatan",
             status_proses="Dalam Penyusunan", tanggal_ttd="", tanggal_mulai=_d(30), tanggal_berakhir=_d(760), ck=(0, 0, 0, 0)),
        dict(jenis="KB", nomor_dokumen="440/009/KB/2022", mitra="Ikatan Ahli Kesehatan Masyarakat (daerah)", kategori_mitra="Organisasi Profesi",
             judul="Kesepakatan bersama pembinaan profesi", tanggal_ttd=_d(-1000), tanggal_mulai=_d(-1000), tanggal_berakhir="", ck=(1, 1, 0, 0)),
        dict(jenis="PKS", nomor_dokumen="440/030/PKS/2025", mitra="Universitas Pelita Mandiri", judul="Magang mahasiswa di Bidang SDMK",
             tanggal_ttd=_d(-340), tanggal_mulai=_d(-340), tanggal_berakhir=_d(25), pj_internal="Staf SDMK", ck=(1, 1, 1, 1)),
    ]
    rows = []
    for i, r in enumerate(data, 1):
        ck = r.pop("ck")
        row = {**base, **r, "id": f"KS-{i:04d}", "diperbarui": ""}
        for k, v in zip(("ck_ttd_lengkap", "ck_arsip", "ck_evaluasi", "ck_perpanjangan"), ck):
            row[k] = _t(bool(v))
        rows.append(row)
    return rows


def _praktik():
    base = dict(jenjang="S1", pembimbing_institusi="", kontak="", link_dokumen="", catatan="", dibatalkan="FALSE")
    data = [
        dict(institusi="Universitas Nusantara Sehat", prodi="Kesehatan Masyarakat", jenis_praktik="PBL / Praktik Lapangan", unit_penempatan="Puskesmas Contoh A",
             jumlah_mahasiswa=12, tanggal_mulai=_d(-20), tanggal_selesai=_d(25), kerjasama_id="KS-0002", pembimbing_lapangan="Bu Sari", ck=(1, 1, 1, 1, 0, 0)),
        dict(institusi="Politeknik Kesehatan Cendana", prodi="Keperawatan", jenjang="D3", jenis_praktik="Praktik Klinik", unit_penempatan="Puskesmas Contoh B",
             jumlah_mahasiswa=8, tanggal_mulai=_d(10), tanggal_selesai=_d(60), kerjasama_id="KS-0004", pembimbing_lapangan="", ck=(1, 1, 0, 0, 0, 0)),
        dict(institusi="Institut Kesehatan Wijaya Kusuma", prodi="Gizi", jenis_praktik="Magang", unit_penempatan="Bidang Kesmas Dinkes",
             jumlah_mahasiswa=5, tanggal_mulai=_d(-90), tanggal_selesai=_d(-40), kerjasama_id="KS-0005", pembimbing_lapangan="Pak Dani", ck=(1, 1, 1, 1, 0, 0)),
        dict(institusi="Universitas Pelita Mandiri", prodi="Administrasi Kebijakan Kesehatan", jenis_praktik="Magang", unit_penempatan="Bidang SDMK Dinkes",
             jumlah_mahasiswa=3, tanggal_mulai=_d(-10), tanggal_selesai=_d(50), kerjasama_id="KS-0008", pembimbing_lapangan="Bu Rina", ck=(1, 1, 1, 1, 0, 0)),
        dict(institusi="STIKes Bhakti Husada", prodi="Kebidanan", jenjang="D4 / Sarjana Terapan", jenis_praktik="Observasi / Kunjungan", unit_penempatan="Puskesmas Contoh C",
             jumlah_mahasiswa=6, tanggal_mulai=_d(90), tanggal_selesai=_d(130), kerjasama_id="", pembimbing_lapangan="", ck=(1, 0, 0, 0, 0, 0)),
        dict(institusi="Universitas Nusantara Sehat", prodi="Kesehatan Masyarakat", jenis_praktik="PBL / Praktik Lapangan", unit_penempatan="Puskesmas Contoh D",
             jumlah_mahasiswa=10, tanggal_mulai=_d(-200), tanggal_selesai=_d(-150), kerjasama_id="KS-0002", pembimbing_lapangan="Pak Hadi", ck=(1, 1, 1, 1, 1, 1)),
    ]
    rows = []
    for i, r in enumerate(data, 1):
        ck = r.pop("ck")
        row = {**base, **r, "id": f"PM-{i:04d}", "diperbarui": ""}
        for k, v in zip(("ck_permohonan", "ck_balasan", "ck_pembimbing", "ck_orientasi", "ck_evaluasi", "ck_laporan"), ck):
            row[k] = _t(bool(v))
        rows.append(row)
    return rows


def _penelitian():
    base = dict(nim_nip="", metode="Kuantitatif", kerjasama_id="", nomor_surat_izin="", pembimbing_lapangan="", kontak="", link_dokumen="", catatan="")
    data = [
        dict(judul="Analisis beban kerja tenaga kesehatan di puskesmas dengan metode WISN", peneliti="Peneliti Contoh A", institusi="Universitas Nusantara Sehat",
             jenis="Skripsi", lokasi="Puskesmas Contoh A", tanggal_pengajuan=_d(-60), status_izin="Disetujui", nomor_surat_izin="070/123/Dinkes/2026",
             tanggal_izin=_d(-45), tanggal_mulai=_d(-30), tanggal_selesai=_d(30), ck=(1, 1, 1, 0)),
        dict(judul="Perencanaan kebutuhan SDMK berbasis ABK-Kes", peneliti="Peneliti Contoh B", institusi="Institut Kesehatan Wijaya Kusuma", jenis="Tesis",
             metode="Kualitatif", lokasi="Dinas Kesehatan", tanggal_pengajuan=_d(-25), status_izin="Diproses", ck=(1, 0, 0, 0), tanggal_izin="", tanggal_mulai="", tanggal_selesai=""),
        dict(judul="Ketersediaan obat esensial dan stockout di puskesmas", peneliti="Peneliti Contoh C", institusi="Politeknik Kesehatan Cendana", jenis="Skripsi",
             lokasi="Puskesmas Contoh B", tanggal_pengajuan=_d(-120), status_izin="Disetujui", nomor_surat_izin="070/089/Dinkes/2026", tanggal_izin=_d(-100),
             tanggal_mulai=_d(-90), tanggal_selesai=_d(-20), ck=(1, 1, 1, 0)),
        dict(judul="Survei kepuasan pasien rawat jalan", peneliti="Peneliti Contoh D", institusi="Universitas Pelita Mandiri", jenis="Skripsi", lokasi="Puskesmas Contoh C",
             tanggal_pengajuan=_d(-50), status_izin="Ditolak", ck=(1, 0, 0, 0), tanggal_izin="", tanggal_mulai="", tanggal_selesai="", catatan="Lokasi di luar wilayah"),
        dict(judul="Kepatuhan SOP pelayanan imunisasi", peneliti="Peneliti Contoh E", institusi="Universitas Nusantara Sehat", jenis="Penelitian Dosen", lokasi="Puskesmas Contoh D",
             tanggal_pengajuan=_d(-300), status_izin="Disetujui", nomor_surat_izin="070/021/Dinkes/2025", tanggal_izin=_d(-290),
             tanggal_mulai=_d(-280), tanggal_selesai=_d(-200), ck=(1, 1, 1, 1)),
    ]
    rows = []
    for i, r in enumerate(data, 1):
        ck = r.pop("ck")
        row = {**base, **r, "id": f"PN-{i:04d}", "diperbarui": ""}
        for k, v in zip(("ck_proposal", "ck_etik", "ck_izin_unit", "ck_laporan_hasil"), ck):
            row[k] = _t(bool(v))
        rows.append(row)
    return rows


def _catatan():
    data = [
        dict(tanggal=_d(-15), ref_id="KS-0003", ringkasan="MoU dengan Poltekkes Cendana sudah berakhir; mitra menyatakan bersedia memperpanjang.",
             tindak_lanjut="Kirim surat usulan perpanjangan dan draf addendum", penanggung_jawab="Staf SDMK", tenggat=_d(-3), status_tl="Proses"),
        dict(tanggal=_d(-5), ref_id="KS-0002", ringkasan="PKS PBL UNS akan berakhir 45 hari lagi; rapat evaluasi dijadwalkan.",
             tindak_lanjut="Siapkan bahan evaluasi dan draf perpanjangan", penanggung_jawab="Staf SDMK", tenggat=_d(5), status_tl="Belum Dimulai"),
        dict(tanggal=_d(-8), ref_id="PM-0003", ringkasan="Magang selesai, form penilaian belum dikembalikan ke kampus.",
             tindak_lanjut="Isi dan kirim form penilaian peserta magang", penanggung_jawab="Pak Dani", tenggat=_d(12), status_tl="Proses"),
        dict(tanggal=_d(-2), ref_id="PN-0003", ringkasan="Pengambilan data selesai; peneliti belum menyerahkan laporan hasil.",
             tindak_lanjut="Ingatkan peneliti menyerahkan laporan hasil", penanggung_jawab="Staf SDMK", tenggat=_d(14), status_tl="Belum Dimulai"),
        dict(tanggal=_d(-30), ref_id="", ringkasan="Rapat koordinasi kerja sama pendidikan: sepakat membuat format laporan kegiatan standar.",
             tindak_lanjut="Susun format laporan praktik dan penelitian", penanggung_jawab="Kasubag", tenggat=_d(-10), status_tl="Selesai"),
    ]
    return [{**r, "id": f"CM-{i:04d}", "diperbarui": ""} for i, r in enumerate(data, 1)]
