"""Ekspor Excel berformat, templat impor, dan pembacaan berkas impor."""
from __future__ import annotations

import io

import pandas as pd
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from . import config as C
from . import logic

NAVY = "0F2F4F"


def _label_map(key: str) -> dict[str, str]:
    m = {"id": "ID", "diperbarui": "Diperbarui"}
    m.update({f.key: f.label for f in C.ENTITIES[key].fields})
    m.update(C.COMPUTED_LABELS)
    m["ref_id"] = "Terkait (ID)"
    return m


def display_frame(key: str, df: pd.DataFrame) -> pd.DataFrame:
    ent = C.ENTITIES[key]
    cols = ["id"] + [f.key for f in ent.fields] + [c for c in ("sisa_hari", "status", "kelengkapan", "status_dasar", "jenis_record") if c in df.columns] + ["diperbarui"]
    out = df[cols].copy()
    for f in ent.fields:
        if f.kind == "bool":
            out[f.key] = out[f.key].map({True: "Ya", False: "Tidak"})
    return out.rename(columns=_label_map(key))


def _style(ws, widths_from: pd.DataFrame) -> None:
    thin = Side(style="thin", color="DDE3EA")
    for c in ws[1]:
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor=NAVY)
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    ws.row_dimensions[1].height = 32
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    for i, name in enumerate(widths_from.columns, 1):
        longest = max([len(str(name))] + [len(str(v)) for v in widths_from.iloc[:, i - 1].head(200)])
        ws.column_dimensions[get_column_letter(i)].width = min(max(12, longest + 2), 55)
    for row in ws.iter_rows(min_row=2):
        for c in row:
            c.border = Border(bottom=thin)
            c.alignment = Alignment(vertical="top", wrap_text=True)
            if hasattr(c.value, "year"):
                c.number_format = "DD/MM/YYYY"


def build_workbook(all_: dict[str, pd.DataFrame], alerts: pd.DataFrame, thr: int) -> bytes:
    buf = io.BytesIO()
    t = logic.today()
    ks, pm, pn, cm = (all_[k] for k in ("kerjasama", "praktik", "penelitian", "catatan"))
    ringkasan = pd.DataFrame({
        "Indikator": ["Tanggal laporan", "Total dokumen kerja sama", "  • Aktif", "  • Segera berakhir", "  • Kedaluwarsa", "  • Dalam penyusunan",
                      "Praktik berlangsung", "Mahasiswa praktik berlangsung", "Penelitian berjalan", "Penelitian menunggu laporan", "Tindak lanjut terbuka", "Peringatan aktif"],
        "Nilai": [t.strftime("%d/%m/%Y"), len(ks), int((ks.status == "Aktif").sum()), int((ks.status == "Segera Berakhir").sum()),
                  int((ks.status == "Kedaluwarsa").sum()), int((ks.status == "Dalam Penyusunan").sum()), int((pm.status == "Berlangsung").sum()),
                  int(pm[pm.status == "Berlangsung"].jumlah_mahasiswa.sum()), int((pn.status == "Berjalan").sum()),
                  int((pn.status == "Selesai - Menunggu Laporan").sum()), int(cm.status.isin(["Belum Dimulai", "Proses", "Terlambat"]).sum()), len(alerts)],
    })
    sheets = {"Ringkasan": ringkasan, "Kerja Sama": display_frame("kerjasama", ks), "Praktik Mahasiswa": display_frame("praktik", pm),
              "Penelitian": display_frame("penelitian", pn), "Catatan Monitoring": display_frame("catatan", cm), "Peringatan": alerts}
    with pd.ExcelWriter(buf, engine="openpyxl") as xw:
        for name, df in sheets.items():
            df.to_excel(xw, sheet_name=name, index=False)
            _style(xw.sheets[name], df)
    return buf.getvalue()


def template(key: str) -> bytes:
    """Templat impor: header memakai label isian + 1 baris contoh."""
    ent = C.ENTITIES[key]
    cols = [f.label for f in ent.fields]
    ex = {}
    for f in ent.fields:
        ex[f.label] = ("2026-01-31" if f.kind in ("date", "date_opt") else "Ya" if f.kind == "bool" else 1 if f.kind == "int"
                       else (f.options or [""])[0] if f.kind == "select" else "contoh")
    df = pd.DataFrame([ex], columns=cols)
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as xw:
        df.to_excel(xw, sheet_name="Data", index=False)
        _style(xw.sheets["Data"], df)
        info = pd.DataFrame({"Petunjuk": ["Hapus baris contoh sebelum mengisi.", "Tanggal format YYYY-MM-DD atau DD/MM/YYYY.",
                                          "Kotak centang diisi Ya / Tidak.", "ID dibuat otomatis, tidak perlu diisi.",
                                          "Kolom bertanda * pada formulir wajib diisi."]})
        info.to_excel(xw, sheet_name="Petunjuk", index=False)
    return buf.getvalue()


def read_import(key: str, file) -> tuple[pd.DataFrame, list[str]]:
    """Baca xlsx/csv -> DataFrame berkolom key internal. Mengembalikan (df, daftar masalah)."""
    ent = C.ENTITIES[key]
    name = getattr(file, "name", "").lower()
    raw = pd.read_csv(file, dtype=str, keep_default_na=False) if name.endswith(".csv") else pd.read_excel(file, dtype=str, keep_default_na=False)
    by_label = {f.label.lower(): f.key for f in ent.fields}
    by_key = {f.key: f.key for f in ent.fields}
    ren = {c: by_label.get(str(c).strip().lower(), by_key.get(str(c).strip())) for c in raw.columns}
    raw = raw.rename(columns=ren)
    raw = raw[[c for c in raw.columns if c in by_key]]
    problems: list[str] = []
    for f in ent.fields:
        if f.key not in raw.columns:
            raw[f.key] = ""
            if f.required:
                problems.append(f"Kolom wajib tidak ditemukan: **{f.label}**")
    for f in ent.fields:
        if f.kind in ("date", "date_opt"):
            parsed = pd.to_datetime(raw[f.key].replace("", pd.NA), errors="coerce", dayfirst=True, format="mixed")
            bad = raw[f.key].astype(str).str.strip().ne("") & parsed.isna()
            if bad.any():
                problems.append(f"{int(bad.sum())} nilai tanggal tidak terbaca di kolom **{f.label}** (baris {', '.join(str(i + 2) for i in raw.index[bad][:5])}…)")
            raw[f.key] = parsed
        elif f.kind == "bool":
            raw[f.key] = raw[f.key].astype(str).str.strip().str.lower().isin(["ya", "true", "1", "yes", "y", "v", "✓"])
        elif f.kind == "int":
            raw[f.key] = pd.to_numeric(raw[f.key], errors="coerce").fillna(0).astype(int)
        elif f.kind == "select" and f.options:
            bad = raw[f.key].astype(str).str.strip().ne("") & ~raw[f.key].isin(f.options)
            if bad.any():
                problems.append(f"{int(bad.sum())} nilai di kolom **{f.label}** tidak sesuai pilihan ({', '.join(f.options)})")
    for f in ent.fields:
        if f.required and f.key in raw.columns and f.kind not in ("date", "bool", "int"):
            miss = raw[f.key].astype(str).str.strip().eq("")
            if miss.any():
                problems.append(f"{int(miss.sum())} baris kosong pada kolom wajib **{f.label}**")
    raw = raw.dropna(how="all")
    return raw, problems
