"""Pembuat formulir otomatis berdasarkan skema Field."""
from __future__ import annotations

import pandas as pd
import streamlit as st

from . import config as C
from .logic import today


def _s(v) -> str:
    return "" if v is None or (isinstance(v, float) and pd.isna(v)) or v is pd.NaT else str(v)


def _options(f: C.F, ctx: dict) -> list:
    opts = list(f.options or [])
    if f.kind == "select_new":
        for v in ctx.get("existing", {}).get(f.key, []):
            if v and v not in opts:
                opts.append(v)
    return opts


def _widget(f: C.F, val, key: str, ctx: dict, is_new: bool):
    label = f.label + (" *" if f.required else "")
    if f.kind in ("text", "url"):
        return st.text_input(label, value=_s(val), key=key, help=f.help, placeholder=f.placeholder)
    if f.kind == "area":
        return st.text_area(label, value=_s(val), key=key, help=f.help, height=95)
    if f.kind == "select":
        opts = _options(f, ctx)
        cur = _s(val) if not is_new else _s(f.default)
        idx = opts.index(cur) if cur in opts else 0
        return st.selectbox(label, opts, index=idx, key=key, help=f.help)
    if f.kind == "select_new":
        opts = _options(f, ctx)
        cur = _s(val)
        idx = opts.index(cur) if cur in opts else None
        res = st.selectbox(label, opts, index=idx, key=key, help=f.help, accept_new_options=True,
                           placeholder="Pilih atau ketik nama baru")
        return (res or "").strip()
    if f.kind == "date":
        d = val.date() if (val is not None and pd.notna(val)) else today().date()
        return st.date_input(label, value=d, key=key, format="DD/MM/YYYY")
    if f.kind == "date_opt":
        has = val is not None and pd.notna(val)
        none = st.checkbox(f"{f.label}: {f.none_label}", value=(f.default_none if is_new else not has), key=key + "_none")
        d = val.date() if has else today().date()
        picked = st.date_input(label, value=d, key=key, format="DD/MM/YYYY", disabled=none)
        return None if none else picked
    if f.kind == "int":
        return int(st.number_input(label, min_value=0, step=1, value=int(val if val not in (None, "") and pd.notna(val) else (f.default or 0)), key=key))
    if f.kind == "ref":
        options = dict(ctx["refs"][f.ref])
        if ctx.get("exclude_id"):
            options.pop(ctx["exclude_id"], None)
        ids = list(options)
        cur = _s(val)
        idx = ids.index(cur) if cur in ids else 0
        return st.selectbox(label, ids, index=idx, format_func=lambda i: options[i], key=key, help=f.help)
    raise ValueError(f"kind tidak dikenal: {f.kind}")


def render_fields(fields: list[C.F], values: dict | None, prefix: str, ctx: dict) -> dict:
    is_new = values is None
    values = values or {}
    out: dict = {}
    normal = [f for f in fields if f.kind != "bool"]
    bools = [f for f in fields if f.kind == "bool"]
    buf: list[C.F] = []

    def flush():
        if not buf:
            return
        cols = st.columns(2)
        for c, f in zip(cols, buf):
            with c:
                out[f.key] = _widget(f, values.get(f.key), f"{prefix}_{f.key}", ctx, is_new)
        buf.clear()

    for f in normal:
        if f.wide:
            flush()
            out[f.key] = _widget(f, values.get(f.key), f"{prefix}_{f.key}", ctx, is_new)
        else:
            buf.append(f)
            if len(buf) == 2:
                flush()
    flush()
    if bools:
        st.markdown("**Kelengkapan & checklist**")
        cols = st.columns(3)
        for i, f in enumerate(bools):
            with cols[i % 3]:
                out[f.key] = st.checkbox(f.label, value=bool(values.get(f.key, False)), key=f"{prefix}_{f.key}", help=f.help)
    return out


def validate(entity: C.Entity, vals: dict) -> list[str]:
    errs = []
    for f in entity.fields:
        if f.required:
            v = vals.get(f.key)
            if v is None or (isinstance(v, str) and not v.strip()):
                errs.append(f"**{f.label}** wajib diisi.")
    start = vals.get("tanggal_mulai")
    end = vals.get("tanggal_berakhir") or vals.get("tanggal_selesai")
    if start and end and end < start:
        errs.append("Tanggal berakhir/selesai tidak boleh lebih awal dari tanggal mulai.")
    return errs


def to_row(vals: dict) -> dict:
    row = {}
    for k, v in vals.items():
        if isinstance(v, str):
            v = v.strip()
        if hasattr(v, "year") and not isinstance(v, pd.Timestamp):
            v = pd.Timestamp(v)
        row[k] = pd.NaT if v is None else v
    return row
