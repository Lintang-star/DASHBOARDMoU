"""Logika bisnis: status otomatis, kelengkapan, peringatan, dan agenda."""
from __future__ import annotations

import pandas as pd

from . import config as C


def today() -> pd.Timestamp:
    return pd.Timestamp.now(tz=C.TIMEZONE).tz_localize(None).normalize()


def _kelengkapan(df: pd.DataFrame, cols: list[str]) -> pd.Series:
    if not cols or df.empty:
        return pd.Series([0] * len(df), index=df.index, dtype="int64")
    return (df[cols].astype(bool).mean(axis=1) * 100).round().astype("int64")


def _days(series: pd.Series, t: pd.Timestamp) -> pd.Series:
    return (series - t).dt.days.astype("Int64")


# ------------------------------------------------------------------ status
def enrich_kerjasama(df: pd.DataFrame, thr: int) -> pd.DataFrame:
    t = today()
    df = df.copy()
    df["sisa_hari"] = _days(df["tanggal_berakhir"], t)

    def status(r) -> str:
        if r.status_proses == "Dalam Penyusunan":
            return "Dalam Penyusunan"
        if r.status_proses == "Dibatalkan":
            return "Dibatalkan"
        if pd.notna(r.tanggal_mulai) and r.tanggal_mulai > t:
            return "Belum Berlaku"
        if pd.isna(r.tanggal_berakhir):
            return "Aktif"
        sisa = (r.tanggal_berakhir - t).days
        if sisa < 0:
            return "Kedaluwarsa"
        return "Segera Berakhir" if sisa <= thr else "Aktif"

    df["status"] = [status(r) for r in df.itertuples()]
    df["kelengkapan"] = _kelengkapan(df, C.KERJASAMA.ck_cols)
    return df


def enrich_praktik(df: pd.DataFrame, ks: pd.DataFrame) -> pd.DataFrame:
    t = today()
    df = df.copy()

    def status(r) -> str:
        if r.dibatalkan:
            return "Dibatalkan"
        if r.tanggal_mulai > t:
            return "Dijadwalkan"
        return "Berlangsung" if r.tanggal_selesai >= t else "Selesai"

    df["status"] = [status(r) for r in df.itertuples()]
    df["kelengkapan"] = _kelengkapan(df, C.PRAKTIK.ck_cols)
    lookup = dict(zip(ks["id"], ks["status"])) if not ks.empty else {}
    df["status_dasar"] = [("Belum terhubung" if not x else lookup.get(x, "Tidak ditemukan")) for x in df["kerjasama_id"]]
    return df


def enrich_penelitian(df: pd.DataFrame, ks: pd.DataFrame) -> pd.DataFrame:
    t = today()
    df = df.copy()

    def status(r) -> str:
        if r.status_izin == "Ditolak":
            return "Ditolak"
        if r.status_izin in ("Diajukan", "Diproses"):
            return "Proses Izin"
        if pd.isna(r.tanggal_mulai) or pd.isna(r.tanggal_selesai):
            return "Disetujui"
        if t < r.tanggal_mulai:
            return "Dijadwalkan"
        if t <= r.tanggal_selesai:
            return "Berjalan"
        return "Selesai" if r.ck_laporan_hasil else "Selesai - Menunggu Laporan"

    df["status"] = [status(r) for r in df.itertuples()]
    df["kelengkapan"] = _kelengkapan(df, C.PENELITIAN.ck_cols)
    return df


def enrich_catatan(df: pd.DataFrame) -> pd.DataFrame:
    t = today()
    df = df.copy()
    df["sisa_hari"] = _days(df["tenggat"], t)

    def status(r) -> str:
        if r.status_tl in ("Selesai", "Tidak Perlu"):
            return r.status_tl
        if pd.notna(r.tenggat) and r.tenggat < t:
            return "Terlambat"
        return r.status_tl

    df["status"] = [status(r) for r in df.itertuples()]
    jenis = {"KS": "Kerja Sama", "PM": "Praktik Mahasiswa", "PN": "Penelitian"}
    df["jenis_record"] = [jenis.get(str(x)[:2], "Umum") if x else "Umum" for x in df["ref_id"]]
    return df


def enrich_all(raw: dict[str, pd.DataFrame], thr: int) -> dict[str, pd.DataFrame]:
    ks = enrich_kerjasama(raw["kerjasama"], thr)
    return {
        "kerjasama": ks,
        "praktik": enrich_praktik(raw["praktik"], ks),
        "penelitian": enrich_penelitian(raw["penelitian"], ks),
        "catatan": enrich_catatan(raw["catatan"]),
    }


# ------------------------------------------------------------------ label
def label_of(key: str, r) -> str:
    g = lambda k: str(r[k]) if k in r and pd.notna(r[k]) else ""  # noqa: E731
    if key == "kerjasama":
        return f"{g('id')} · {g('jenis')} · {g('mitra')} · {g('nomor_dokumen')}"
    if key == "praktik":
        return f"{g('id')} · {g('institusi')} · {g('prodi')} · {g('unit_penempatan')}"
    if key == "penelitian":
        return f"{g('id')} · {g('peneliti')} · {g('judul')[:60]}"
    return f"{g('id')} · {g('ringkasan')[:60]}"


def build_refs(all_: dict[str, pd.DataFrame]) -> dict[str, dict[str, str]]:
    """Pilihan referensi untuk isian bertipe ref. Nilai kosong = tidak ada."""
    refs = {"kerjasama": {"": "— tidak ada —"}, "all": {"": "Umum (tidak terkait dokumen tertentu)"}}
    for key in ("kerjasama", "praktik", "penelitian"):
        for r in all_[key].to_dict("records"):
            lab = label_of(key, r)
            if key == "kerjasama":
                refs["kerjasama"][r["id"]] = lab
            refs["all"][r["id"]] = lab
    return refs


# ------------------------------------------------------------------ peringatan
def build_alerts(all_: dict[str, pd.DataFrame], thr: int) -> pd.DataFrame:
    t = today()
    rows: list[dict] = []

    def add(level, kategori, rid, uraian, tanggal=None):
        sisa = int((tanggal - t).days) if tanggal is not None and pd.notna(tanggal) else None
        rows.append({"Tingkat": level, "Kategori": kategori, "ID": rid, "Uraian": uraian,
                     "Tanggal": tanggal if tanggal is not None and pd.notna(tanggal) else pd.NaT, "Sisa Hari": sisa})

    for r in all_["kerjasama"].itertuples():
        nama = f"{r.jenis} {r.nomor_dokumen} – {r.mitra}"
        proses = " (perpanjangan sedang diproses)" if r.ck_perpanjangan else ""
        if r.status == "Kedaluwarsa":
            add("Info" if r.ck_perpanjangan else "Tinggi", "Kerja Sama", r.id,
                f"{nama} sudah kedaluwarsa{proses}", r.tanggal_berakhir)
        elif r.status == "Segera Berakhir":
            lvl = "Info" if r.ck_perpanjangan else ("Tinggi" if r.sisa_hari <= 30 else "Sedang")
            add(lvl, "Kerja Sama", r.id, f"{nama} akan berakhir{proses}", r.tanggal_berakhir)
        elif r.status == "Aktif" and not r.ck_ttd_lengkap:
            add("Info", "Kerja Sama", r.id, f"{nama}: tanda tangan kedua pihak belum dicentang", None)

    for r in all_["praktik"].itertuples():
        nama = f"Praktik {r.institusi} ({r.prodi}) di {r.unit_penempatan}"
        if r.status == "Dibatalkan":
            continue
        if r.status_dasar in ("Kedaluwarsa", "Dibatalkan", "Tidak ditemukan"):
            add("Tinggi", "Praktik", r.id, f"{nama}: dasar kerja sama berstatus {r.status_dasar.lower()}", r.tanggal_mulai)
        elif r.status_dasar == "Belum terhubung":
            add("Info", "Praktik", r.id, f"{nama}: belum dihubungkan ke dokumen kerja sama", r.tanggal_mulai)
        if r.status == "Dijadwalkan" and (r.tanggal_mulai - t).days <= 14 and not (r.ck_balasan and r.ck_pembimbing):
            add("Sedang", "Praktik", r.id, f"{nama}: mulai ≤14 hari, surat balasan/pembimbing belum lengkap", r.tanggal_mulai)
        if r.status == "Berlangsung" and not str(r.pembimbing_lapangan).strip():
            add("Sedang", "Praktik", r.id, f"{nama}: sedang berlangsung tanpa pembimbing lapangan", r.tanggal_selesai)
        if r.status == "Selesai" and not (r.ck_evaluasi and r.ck_laporan):
            add("Sedang", "Praktik", r.id, f"{nama}: sudah selesai, evaluasi/laporan akhir belum lengkap", r.tanggal_selesai)

    for r in all_["penelitian"].itertuples():
        nama = f"Penelitian {r.peneliti} – {str(r.judul)[:50]}"
        if r.status == "Selesai - Menunggu Laporan":
            add("Sedang", "Penelitian", r.id, f"{nama}: pengambilan data selesai, laporan hasil belum diserahkan", r.tanggal_selesai)
        if r.status == "Proses Izin" and pd.notna(r.tanggal_pengajuan) and (t - r.tanggal_pengajuan).days > 14:
            add("Sedang", "Penelitian", r.id, f"{nama}: izin diproses >14 hari sejak pengajuan", r.tanggal_pengajuan)
        if r.status in ("Berjalan", "Dijadwalkan") and not r.ck_etik:
            add("Info", "Penelitian", r.id, f"{nama}: kaji etik belum tercatat", r.tanggal_mulai)

    for r in all_["catatan"].itertuples():
        if r.status == "Terlambat":
            add("Tinggi", "Tindak Lanjut", r.id, f"Tindak lanjut terlambat: {str(r.tindak_lanjut or r.ringkasan)[:80]}", r.tenggat)
        elif r.status in ("Belum Dimulai", "Proses") and pd.notna(r.tenggat) and (r.tenggat - t).days <= 7:
            add("Sedang", "Tindak Lanjut", r.id, f"Tenggat ≤7 hari: {str(r.tindak_lanjut or r.ringkasan)[:80]}", r.tenggat)

    cols = ["Tingkat", "Kategori", "ID", "Uraian", "Tanggal", "Sisa Hari"]
    out = pd.DataFrame(rows, columns=cols)
    if out.empty:
        return out
    out["_o"] = out["Tingkat"].map({"Tinggi": 0, "Sedang": 1, "Info": 2})
    out = out.sort_values(["_o", "Sisa Hari"], na_position="last").drop(columns="_o").reset_index(drop=True)
    return out


# ------------------------------------------------------------------ agenda
def build_agenda(all_: dict[str, pd.DataFrame], start: pd.Timestamp, end: pd.Timestamp) -> pd.DataFrame:
    rows: list[dict] = []

    def add(tgl, jenis, rid, uraian):
        if pd.notna(tgl) and start <= tgl <= end:
            rows.append({"Tanggal": tgl, "Agenda": jenis, "ID": rid, "Uraian": uraian})

    for r in all_["kerjasama"].itertuples():
        if r.status not in ("Dibatalkan",):
            add(r.tanggal_berakhir, "Kerja sama berakhir", r.id, f"{r.jenis} {r.nomor_dokumen} – {r.mitra}")
        if r.status in ("Belum Berlaku", "Dalam Penyusunan"):
            add(r.tanggal_mulai, "Kerja sama mulai berlaku", r.id, f"{r.jenis} {r.nomor_dokumen} – {r.mitra}")
    for r in all_["praktik"].itertuples():
        if r.status == "Dibatalkan":
            continue
        add(r.tanggal_mulai, "Praktik mulai", r.id, f"{r.institusi} – {r.prodi} ({r.jumlah_mahasiswa} mhs) di {r.unit_penempatan}")
        add(r.tanggal_selesai, "Praktik selesai", r.id, f"{r.institusi} – {r.prodi} di {r.unit_penempatan}")
    for r in all_["penelitian"].itertuples():
        if r.status == "Ditolak":
            continue
        add(r.tanggal_mulai, "Penelitian mulai", r.id, f"{r.peneliti} – {str(r.judul)[:60]}")
        add(r.tanggal_selesai, "Penelitian selesai", r.id, f"{r.peneliti} – {str(r.judul)[:60]}")
    for r in all_["catatan"].itertuples():
        if r.status in ("Belum Dimulai", "Proses", "Terlambat"):
            add(r.tenggat, "Tenggat tindak lanjut", r.id, str(r.tindak_lanjut or r.ringkasan)[:80])

    out = pd.DataFrame(rows, columns=["Tanggal", "Agenda", "ID", "Uraian"])
    return out.sort_values("Tanggal").reset_index(drop=True)
