"""Lapisan penyimpanan: CSV lokal (demo/uji) atau Google Sheets (permanen untuk Streamlit Cloud)."""
from __future__ import annotations

from pathlib import Path

import pandas as pd
import streamlit as st

from . import config as C
from .logic import today

DATA_DIR = Path(__file__).resolve().parent.parent / "data"
SCOPES = ["https://www.googleapis.com/auth/spreadsheets", "https://www.googleapis.com/auth/drive"]


def columns(key: str) -> list[str]:
    return ["id"] + [f.key for f in C.ENTITIES[key].fields] + ["diperbarui"]


def _now() -> str:
    return pd.Timestamp.now(tz=C.TIMEZONE).strftime("%Y-%m-%d %H:%M")


# ------------------------------------------------------------ konversi tipe
def coerce(key: str, raw: pd.DataFrame) -> pd.DataFrame:
    """Teks mentah -> tipe data (tanggal, bilangan, boolean)."""
    df = raw.copy()
    for c in columns(key):
        if c not in df.columns:
            df[c] = ""
    df = df[columns(key)]
    for f in C.ENTITIES[key].fields:
        if f.kind in ("date", "date_opt"):
            df[f.key] = pd.to_datetime(df[f.key].replace("", pd.NA), errors="coerce")
        elif f.kind == "int":
            df[f.key] = pd.to_numeric(df[f.key], errors="coerce").fillna(0).astype(int)
        elif f.kind == "bool":
            df[f.key] = df[f.key].astype(str).str.strip().str.upper().isin(["TRUE", "1", "YA", "YES", "Y"])
        else:
            df[f.key] = df[f.key].fillna("").astype(str)
    df["id"] = df["id"].astype(str)
    df["diperbarui"] = df["diperbarui"].fillna("").astype(str)
    return df.reset_index(drop=True)


def serialize(key: str, df: pd.DataFrame) -> pd.DataFrame:
    """Tipe data -> teks (aman untuk CSV / Google Sheets)."""
    out = df.copy()
    for c in columns(key):
        if c not in out.columns:
            out[c] = ""
    out = out[columns(key)]
    for f in C.ENTITIES[key].fields:
        if f.kind in ("date", "date_opt"):
            out[f.key] = pd.to_datetime(out[f.key], errors="coerce").dt.strftime("%Y-%m-%d").fillna("")
        elif f.kind == "int":
            out[f.key] = pd.to_numeric(out[f.key], errors="coerce").fillna(0).astype(int).astype(str)
        elif f.kind == "bool":
            out[f.key] = out[f.key].fillna(False).astype(bool).map({True: "TRUE", False: "FALSE"})
        else:
            out[f.key] = out[f.key].fillna("").astype(str)
    return out.fillna("").astype(str)


# ------------------------------------------------------------ backend
class LocalBackend:
    label = "Lokal (file CSV)"
    persistent = False

    def read(self, key: str) -> pd.DataFrame:
        path = DATA_DIR / f"{key}.csv"
        if not path.exists():
            from . import demo
            DATA_DIR.mkdir(exist_ok=True)
            serialize(key, coerce(key, demo.generate(key))).to_csv(path, index=False)
        return pd.read_csv(path, dtype=str, keep_default_na=False)

    def write(self, key: str, df: pd.DataFrame) -> None:
        DATA_DIR.mkdir(exist_ok=True)
        df.to_csv(DATA_DIR / f"{key}.csv", index=False)


class GSheetsBackend:
    label = "Google Sheets"
    persistent = True

    def __init__(self):
        import gspread
        from google.oauth2.service_account import Credentials

        creds = Credentials.from_service_account_info(dict(st.secrets["gcp_service_account"]), scopes=SCOPES)
        self.sh = gspread.authorize(creds).open_by_url(st.secrets["gsheets"]["spreadsheet_url"])
        self._gspread = gspread

    def _ws(self, key: str):
        try:
            return self.sh.worksheet(key)
        except self._gspread.WorksheetNotFound:
            ws = self.sh.add_worksheet(title=key, rows=500, cols=len(columns(key)) + 2)
            ws.update(values=[columns(key)], range_name="A1", value_input_option="RAW")
            return ws

    def read(self, key: str) -> pd.DataFrame:
        vals = self._ws(key).get_all_values()
        if len(vals) < 2:
            return pd.DataFrame(columns=columns(key))
        return pd.DataFrame(vals[1:], columns=vals[0])

    def write(self, key: str, df: pd.DataFrame) -> None:
        ws = self._ws(key)
        data = [columns(key)] + df[columns(key)].values.tolist()
        ws.clear()
        ws.update(values=data, range_name="A1", value_input_option="RAW")


@st.cache_resource(show_spinner="Menghubungkan ke penyimpanan data…")
def backend():
    try:
        use_gs = "gcp_service_account" in st.secrets and "gsheets" in st.secrets
    except Exception:  # tidak ada file secrets
        use_gs = False
    return GSheetsBackend() if use_gs else LocalBackend()


@st.cache_data(ttl=45, show_spinner=False)
def _read_raw(key: str) -> pd.DataFrame:
    return backend().read(key)


def clear_cache() -> None:
    _read_raw.clear()


# ------------------------------------------------------------ API publik
def load(key: str) -> pd.DataFrame:
    return coerce(key, _read_raw(key))


def load_all() -> dict[str, pd.DataFrame]:
    return {k: load(k) for k in C.ENTITIES}


def _fresh(key: str) -> pd.DataFrame:
    clear_cache()
    return coerce(key, backend().read(key))


def _write(key: str, df: pd.DataFrame) -> None:
    backend().write(key, serialize(key, df))
    clear_cache()


def next_id(key: str, df: pd.DataFrame, offset: int = 1) -> str:
    prefix = C.ENTITIES[key].prefix
    nums = pd.to_numeric(df["id"].str.extract(r"(\d+)$")[0], errors="coerce").dropna()
    return f"{prefix}-{(int(nums.max()) if len(nums) else 0) + offset:04d}"


def upsert(key: str, row: dict) -> str:
    """Tambah (id kosong) atau ubah (id ada). Mengembalikan id."""
    df = _fresh(key)
    row = dict(row)
    row["diperbarui"] = _now()
    if not row.get("id"):
        row["id"] = next_id(key, df)
        df = pd.concat([df, pd.DataFrame([row])], ignore_index=True)
    elif (df["id"] == row["id"]).any():
        idx = df.index[df["id"] == row["id"]][0]
        for k, v in row.items():
            df.at[idx, k] = v
    else:
        df = pd.concat([df, pd.DataFrame([row])], ignore_index=True)
    _write(key, df)
    return row["id"]


def delete(key: str, rid: str) -> None:
    df = _fresh(key)
    _write(key, df[df["id"] != rid])


def bulk_append(key: str, new: pd.DataFrame) -> int:
    df = _fresh(key)
    new = new.copy()
    ids = []
    for i in range(len(new)):
        ids.append(next_id(key, df, offset=i + 1))
    new["id"] = ids
    new["diperbarui"] = _now()
    _write(key, pd.concat([df, coerce(key, serialize(key, new))], ignore_index=True))
    return len(new)


def reset(key: str) -> None:
    _write(key, pd.DataFrame(columns=columns(key)))
