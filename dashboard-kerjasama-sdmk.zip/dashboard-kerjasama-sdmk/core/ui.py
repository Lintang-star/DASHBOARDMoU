"""Komponen tampilan: tema CSS, login, sidebar, header, kartu KPI, gaya grafik."""
from __future__ import annotations

import hmac
from html import escape

import streamlit as st

from . import config as C
from . import store

CSS = f"""
<style>
.stApp {{ background: {C.COLORS['bg']}; }}
.block-container {{ padding-top: 3.6rem; max-width: 1450px; }}
h1, h2, h3, h4 {{ color: {C.COLORS['navy']} !important; letter-spacing: -0.01em; }}
[data-testid="stSidebar"] {{ border-right: 1px solid {C.COLORS['border']}; }}
.brand {{ background: linear-gradient(135deg, {C.COLORS['navy']}, {C.COLORS['teal']}); color: #fff;
  border-radius: 12px; padding: .85rem 1rem; margin-bottom: .6rem; border-bottom: 3px solid {C.COLORS['gold']}; }}
.brand b {{ font-size: 1.02rem; }} .brand span {{ display:block; font-size:.74rem; color:#D5E4EA; margin-top:.15rem; }}
.hero {{ background: linear-gradient(120deg, {C.COLORS['navy']} 0%, {C.COLORS['teal']} 100%); color: #fff;
  padding: 1.1rem 1.5rem; border-radius: 14px; margin-bottom: 1.1rem; border-bottom: 4px solid {C.COLORS['gold']}; }}
.hero .t {{ font-size: 1.55rem; font-weight: 700; line-height: 1.2; }}
.hero .s {{ color: #D5E4EA; font-size: .93rem; margin-top: .25rem; }}
.kpi {{ background: {C.COLORS['card']}; border: 1px solid {C.COLORS['border']}; border-left: 5px solid var(--c);
  border-radius: 12px; padding: .75rem 1rem; box-shadow: 0 1px 3px rgba(15,47,79,.06); height: 100%; }}
.kpi .l {{ color: {C.COLORS['muted']}; font-size: .74rem; text-transform: uppercase; letter-spacing: .05em; font-weight: 600; }}
.kpi .v {{ color: {C.COLORS['navy']}; font-size: 1.9rem; font-weight: 700; line-height: 1.15; }}
.kpi .n {{ color: {C.COLORS['muted']}; font-size: .78rem; }}
.card {{ background: {C.COLORS['card']}; border: 1px solid {C.COLORS['border']}; border-radius: 12px; padding: .9rem 1.1rem; }}
.stTabs [data-baseweb="tab-list"] {{ gap: .25rem; }}
.stTabs [data-baseweb="tab"] {{ background: #E8EEF4; border-radius: 8px 8px 0 0; padding: .45rem 1rem; }}
.stTabs [aria-selected="true"] {{ background: {C.COLORS['card']}; border-bottom: 3px solid {C.COLORS['gold']}; font-weight: 600; }}
[data-testid="stForm"] {{ background: {C.COLORS['card']}; border: 1px solid {C.COLORS['border']}; border-radius: 12px; }}
div.stButton > button[kind="primary"], div[data-testid="stFormSubmitButton"] > button[kind="primaryFormSubmit"] {{
  background: {C.COLORS['navy']}; border: none; }}
div.stButton > button[kind="primary"]:hover {{ background: {C.COLORS['teal']}; }}
</style>
"""


def _secret(name: str):
    try:
        return st.secrets.get(name)
    except Exception:
        return None


def setup_global() -> int:
    """Dipanggil sekali dari app.py: tema, login, sidebar. Mengembalikan batas peringatan (hari)."""
    st.markdown(CSS, unsafe_allow_html=True)
    _login_gate()
    return _sidebar()


def _login_gate() -> None:
    pw = _secret("app_password")
    if not pw or st.session_state.get("auth_ok"):
        return
    _, mid, _ = st.columns([1, 1.2, 1])
    with mid:
        st.markdown(f'<div class="hero"><div class="t">🔐 {C.APP_NAME}</div><div class="s">Masuk untuk melanjutkan</div></div>',
                    unsafe_allow_html=True)
        with st.form("login"):
            x = st.text_input("Kata sandi", type="password")
            if st.form_submit_button("Masuk", type="primary"):
                if hmac.compare_digest(x.encode(), str(pw).encode()):
                    st.session_state["auth_ok"] = True
                    st.rerun()
                st.error("Kata sandi salah.")
    st.stop()


def _sidebar() -> int:
    with st.sidebar:
        st.markdown(f'<div class="brand"><b>🏛️ {C.APP_NAME}</b><span>Sub-bagian SDMK · Pemantauan kerja sama</span></div>',
                    unsafe_allow_html=True)
    return st.session_state.get("thr", C.DEFAULT_THRESHOLD_DAYS)


def sidebar_settings() -> int:
    """Pengaturan di bagian bawah sidebar (dipanggil setelah navigasi)."""
    with st.sidebar:
        st.divider()
        thr = st.slider("Batas peringatan 'Segera Berakhir' (hari)", 30, 365, st.session_state.get("thr", C.DEFAULT_THRESHOLD_DAYS), 15,
                        help="Dokumen yang berakhir dalam rentang ini ditandai 'Segera Berakhir'.")
        st.session_state["thr"] = thr
        if st.button("🔄 Muat ulang data", width="stretch"):
            store.clear_cache()
            st.rerun()
        b = store.backend()
        st.caption(f"Penyimpanan: **{b.label}**")
        if not b.persistent:
            st.warning("Mode lokal/demo. Di Streamlit Cloud data CSV akan hilang saat aplikasi restart — "
                       "hubungkan Google Sheets (lihat README).", icon="⚠️")
        if _secret("app_password"):
            if st.button("Keluar", width="stretch"):
                st.session_state.pop("auth_ok", None)
                st.rerun()
    return thr


def hero(title: str, subtitle: str = "", icon: str = "") -> None:
    st.markdown(f'<div class="hero"><div class="t">{icon} {escape(title)}</div><div class="s">{escape(subtitle)}</div></div>',
                unsafe_allow_html=True)
    msg = st.session_state.pop("flash", None)
    if msg:
        st.success(msg, icon="✅")


def flash(msg: str) -> None:
    st.session_state["flash"] = msg


def kpi(col, label: str, value, note: str = "", color: str = C.COLORS["teal"]) -> None:
    col.markdown(f'<div class="kpi" style="--c:{color}"><div class="l">{escape(label)}</div><div class="v">{value}</div>'
                 f'<div class="n">{escape(note)}</div></div>', unsafe_allow_html=True)


def style_fig(fig, height: int = 330):
    fig.update_layout(height=height, margin=dict(l=10, r=10, t=40, b=10), paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                      font=dict(family="sans-serif", color=C.COLORS["text"], size=12),
                      title=dict(font=dict(size=14, color=C.COLORS["navy"])), legend=dict(orientation="h", y=-0.15))
    fig.update_xaxes(gridcolor="#E6EBF1", zeroline=False)
    fig.update_yaxes(gridcolor="#E6EBF1", zeroline=False)
    return fig
