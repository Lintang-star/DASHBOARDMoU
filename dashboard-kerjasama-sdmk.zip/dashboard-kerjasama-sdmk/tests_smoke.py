"""Uji asap: jalankan semua halaman dengan Streamlit AppTest. Jalankan: python tests_smoke.py"""
from streamlit.testing.v1 import AppTest

for page in ["beranda", "agenda", "kerjasama", "praktik", "penelitian", "catatan", "laporan"]:
    at = AppTest.from_file(f"views/{page}.py", default_timeout=60).run()
    assert not at.exception, (page, [e.value for e in at.exception])
    print("OK", page)
at = AppTest.from_file("app.py", default_timeout=60).run()
assert not at.exception, [e.value for e in at.exception]
print("OK app.py")
