import pandas as pd
import streamlit as st

from core import config as C
from core import logic, store, ui

thr = st.session_state.get("thr", C.DEFAULT_THRESHOLD_DAYS)
ui.hero("Agenda & Pengingat", "Semua tanggal penting dalam satu daftar: berakhirnya dokumen, praktik, penelitian, dan tenggat tindak lanjut", "🗓️")
all_ = logic.enrich_all(store.load_all(), thr)

c1, c2 = st.columns([1, 3])
horizon = c1.selectbox("Rentang waktu", [30, 60, 90, 180, 365], index=2, format_func=lambda d: f"{d} hari ke depan")
past = c1.checkbox("Sertakan 30 hari ke belakang", value=True)
start = logic.today() - pd.Timedelta(days=30 if past else 0)
ag = logic.build_agenda(all_, start, logic.today() + pd.Timedelta(days=horizon))
jenis = c2.multiselect("Jenis agenda", sorted(ag["Agenda"].unique()) if not ag.empty else [], placeholder="Semua jenis")
if jenis:
    ag = ag[ag["Agenda"].isin(jenis)]

if ag.empty:
    st.info("Tidak ada agenda pada rentang ini.")
else:
    t = logic.today()
    ag["Sisa Hari"] = (ag["Tanggal"] - t).dt.days

    def grp(d):
        return ("🔴 Sudah lewat" if d < 0 else "🟠 Minggu ini (0–7 hari)" if d <= 7 else "🟡 Bulan ini (8–30 hari)" if d <= 30 else "🔵 Lebih dari 30 hari")

    ag["Kelompok"] = ag["Sisa Hari"].map(grp)
    for g in ["🔴 Sudah lewat", "🟠 Minggu ini (0–7 hari)", "🟡 Bulan ini (8–30 hari)", "🔵 Lebih dari 30 hari"]:
        sub = ag[ag.Kelompok == g]
        if sub.empty:
            continue
        st.markdown(f"#### {g} · {len(sub)}")
        st.dataframe(sub[["Tanggal", "Sisa Hari", "Agenda", "ID", "Uraian"]], hide_index=True, width="stretch", column_config={
            "Tanggal": st.column_config.DateColumn("Tanggal", format="DD MMM YYYY"),
            "Sisa Hari": st.column_config.NumberColumn("Sisa Hari", format="%d"),
            "Uraian": st.column_config.TextColumn("Uraian", width="large")})

    # ekspor kalender .ics
    def ics() -> str:
        lines = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Dashboard Kerja Sama SDMK//ID", "CALSCALE:GREGORIAN"]
        for r in ag.itertuples():
            d = r.Tanggal.strftime("%Y%m%d")
            nxt = (r.Tanggal + pd.Timedelta(days=1)).strftime("%Y%m%d")
            summ = f"{r.Agenda}: {r.Uraian}".replace(",", "\\,").replace(";", "\\;")
            lines += ["BEGIN:VEVENT", f"UID:{r.ID}-{d}-{abs(hash(r.Agenda)) % 9999}@sdmk", f"DTSTAMP:{t.strftime('%Y%m%d')}T000000Z",
                      f"DTSTART;VALUE=DATE:{d}", f"DTEND;VALUE=DATE:{nxt}", f"SUMMARY:{summ}", "BEGIN:VALARM", "TRIGGER:-P3D", "ACTION:DISPLAY",
                      "DESCRIPTION:Pengingat", "END:VALARM", "END:VEVENT"]
        lines.append("END:VCALENDAR")
        return "\r\n".join(lines)

    st.download_button("📅 Unduh sebagai kalender (.ics) — impor ke Google Calendar/Outlook", ics(), file_name="agenda_sdmk.ics", mime="text/calendar")
