import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from core import config as C
from core import logic, store, ui

thr = st.session_state.get("thr", C.DEFAULT_THRESHOLD_DAYS)
ui.hero("Ringkasan Pemantauan", f"{C.APP_TAGLINE} · per {logic.today():%d %B %Y}", "📊")

all_ = logic.enrich_all(store.load_all(), thr)
ks, pm, pn, cm = all_["kerjasama"], all_["praktik"], all_["penelitian"], all_["catatan"]
col = C.COLORS

# ------------------------------------------------------------------ KPI
r1 = st.columns(5)
ui.kpi(r1[0], "Dokumen kerja sama", len(ks), f"MoU {int((ks.jenis=='MoU').sum())} · PKS {int((ks.jenis=='PKS').sum())} · KB {int((ks.jenis=='KB').sum())}", col["navy"])
ui.kpi(r1[1], "Aktif", int((ks.status == "Aktif").sum()), "masa berlaku aman", col["green"])
ui.kpi(r1[2], "Segera berakhir", int((ks.status == "Segera Berakhir").sum()), f"≤ {thr} hari", col["amber"])
ui.kpi(r1[3], "Kedaluwarsa", int((ks.status == "Kedaluwarsa").sum()), "perlu diperpanjang", col["red"])
ui.kpi(r1[4], "Dalam penyusunan", int((ks.status == "Dalam Penyusunan").sum()), "draf / proses", col["blue"])
st.write("")
r2 = st.columns(5)
berlangsung = pm[pm.status == "Berlangsung"]
ui.kpi(r2[0], "Praktik berlangsung", len(berlangsung), f"{int(berlangsung.jumlah_mahasiswa.sum())} mahasiswa", col["teal"])
ui.kpi(r2[1], "Praktik dijadwalkan", int((pm.status == "Dijadwalkan").sum()), "akan datang", col["blue"])
ui.kpi(r2[2], "Penelitian berjalan", int(pn.status.isin(["Berjalan"]).sum()), f"{int((pn.status=='Proses Izin').sum())} proses izin", col["teal"])
ui.kpi(r2[3], "Menunggu laporan", int((pn.status == "Selesai - Menunggu Laporan").sum()), "penelitian selesai", col["gold"])
ui.kpi(r2[4], "Tindak lanjut terbuka", int(cm.status.isin(["Belum Dimulai", "Proses", "Terlambat"]).sum()), f"{int((cm.status=='Terlambat').sum())} terlambat", col["red"])
st.write("")

# ------------------------------------------------------------------ perhatian + agenda
alerts = logic.build_alerts(all_, thr)
left, right = st.columns([3, 2])
with left:
    st.subheader("⚠️ Perlu perhatian")
    if alerts.empty:
        st.success("Tidak ada peringatan. Semua aman 👍")
    else:
        n = alerts.Tingkat.value_counts()
        st.caption(f"🔴 {n.get('Tinggi', 0)} tinggi · 🟠 {n.get('Sedang', 0)} sedang · 🔵 {n.get('Info', 0)} info")
        view = alerts.head(12).copy()
        view["Tingkat"] = view["Tingkat"].map(C.LEVEL_ICON)
        st.dataframe(view, hide_index=True, width="stretch", height=430, column_config={
            "Tanggal": st.column_config.DateColumn("Tanggal", format="DD MMM YYYY"),
            "Sisa Hari": st.column_config.NumberColumn("Sisa Hari", format="%d"),
            "Uraian": st.column_config.TextColumn("Uraian", width="large"),
            "ID": st.column_config.TextColumn("ID", width="small")})
        if len(alerts) > 12:
            st.caption(f"+ {len(alerts) - 12} peringatan lain. Lihat selengkapnya di halaman Laporan.")
with right:
    st.subheader("🗓️ Agenda 30 hari ke depan")
    ag = logic.build_agenda(all_, logic.today(), logic.today() + pd.Timedelta(days=30))
    if ag.empty:
        st.info("Tidak ada agenda dalam 30 hari ke depan.")
    else:
        st.dataframe(ag, hide_index=True, width="stretch", height=430, column_config={
            "Tanggal": st.column_config.DateColumn("Tanggal", format="DD MMM"),
            "Uraian": st.column_config.TextColumn("Uraian", width="large"),
            "ID": st.column_config.TextColumn("ID", width="small")})

st.divider()
st.subheader("📈 Visualisasi")

# ------------------------------------------------------------------ grafik
g1, g2, g3 = st.columns(3)
with g1:
    if ks.empty:
        st.info("Belum ada data kerja sama.")
    else:
        d = ks.status.value_counts().reset_index()
        d.columns = ["Status", "Jumlah"]
        fig = px.pie(d, names="Status", values="Jumlah", hole=.58, color="Status", color_discrete_map=C.STATUS_COLOR, title="Status dokumen kerja sama")
        fig.update_traces(textinfo="value", sort=False)
        st.plotly_chart(ui.style_fig(fig), width="stretch")
with g2:
    if not ks.empty:
        d = ks.groupby(["jenis", "status"]).size().reset_index(name="Jumlah")
        fig = px.bar(d, x="jenis", y="Jumlah", color="status", color_discrete_map=C.STATUS_COLOR, title="Jenis dokumen per status",
                     category_orders={"jenis": C.JENIS_KS}, labels={"jenis": "", "status": "Status"})
        st.plotly_chart(ui.style_fig(fig), width="stretch")
with g3:
    if not ks.empty:
        d = ks[ks.status != "Dibatalkan"].groupby("mitra").size().sort_values().tail(8).reset_index(name="Jumlah")
        fig = px.bar(d, x="Jumlah", y="mitra", orientation="h", title="Mitra dengan dokumen terbanyak", labels={"mitra": ""},
                     color_discrete_sequence=[col["teal"]])
        st.plotly_chart(ui.style_fig(fig), width="stretch")

# Gantt masa berlaku
gx = ks[ks.tanggal_berakhir.notna() & ks.tanggal_mulai.notna() & ~ks.status.isin(["Dibatalkan"])].copy()
if not gx.empty:
    gx["Dokumen"] = gx["jenis"] + " · " + gx["mitra"].str.slice(0, 28) + " (" + gx["id"] + ")"
    gx = gx.sort_values("tanggal_berakhir")
    fig = px.timeline(gx, x_start="tanggal_mulai", x_end="tanggal_berakhir", y="Dokumen", color="status",
                      color_discrete_map=C.STATUS_COLOR, title="Linimasa masa berlaku dokumen kerja sama", labels={"status": "Status"})
    fig.update_yaxes(autorange="reversed", title="")
    fig.add_shape(type="line", x0=logic.today(), x1=logic.today(), y0=0, y1=1, yref="paper", line=dict(color=col["gold"], width=2, dash="dash"))
    fig.add_annotation(x=logic.today(), y=1.04, yref="paper", text="Hari ini", showarrow=False, font=dict(color=col["gold"], size=12))
    st.plotly_chart(ui.style_fig(fig, height=max(280, 34 * len(gx) + 120)), width="stretch")

h1, h2, h3 = st.columns(3)
with h1:
    if not pm.empty:
        d = pm[pm.status != "Dibatalkan"].copy()
        d["Bulan"] = d["tanggal_mulai"].dt.to_period("M").dt.to_timestamp()
        d = d.groupby("Bulan")["jumlah_mahasiswa"].sum().reset_index()
        fig = px.bar(d, x="Bulan", y="jumlah_mahasiswa", title="Mahasiswa praktik per bulan mulai", labels={"jumlah_mahasiswa": "Mahasiswa", "Bulan": ""},
                     color_discrete_sequence=[col["navy"]])
        st.plotly_chart(ui.style_fig(fig), width="stretch")
with h2:
    if not pm.empty:
        d = pm.status.value_counts().reset_index()
        d.columns = ["Status", "Jumlah"]
        fig = px.bar(d, x="Status", y="Jumlah", color="Status", color_discrete_map=C.STATUS_COLOR, title="Status praktik mahasiswa")
        fig.update_layout(showlegend=False)
        st.plotly_chart(ui.style_fig(fig), width="stretch")
with h3:
    if not pn.empty:
        d = pn.status.value_counts().reset_index()
        d.columns = ["Status", "Jumlah"]
        fig = px.pie(d, names="Status", values="Jumlah", hole=.58, color="Status", color_discrete_map=C.STATUS_COLOR, title="Status penelitian")
        fig.update_traces(textinfo="value")
        st.plotly_chart(ui.style_fig(fig), width="stretch")
