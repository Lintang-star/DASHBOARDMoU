import streamlit as st

from core import crud, ui

ui.hero("Catatan Monitoring & Tindak Lanjut", "Rekam hasil monitoring dan pantau tindak lanjut sampai tuntas", "📝")
crud.run("catatan", st.session_state.get("thr", 90))
