import streamlit as st

from core import crud, ui

ui.hero("Kerja Sama: MoU, PKS & Kesepakatan Bersama", "Daftar, catat, dan pantau masa berlaku seluruh dokumen kerja sama", "📑")
crud.run("kerjasama", st.session_state.get("thr", 90))
