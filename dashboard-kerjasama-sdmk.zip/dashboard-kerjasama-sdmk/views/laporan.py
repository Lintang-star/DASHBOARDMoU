import pandas as pd
import streamlit as st

from core import config as C
from core import export, logic, store, ui

thr = st.session_state.get("thr", C.DEFAULT_THRESHOLD_DAYS)
ui.hero("Laporan, Impor & Ekspor", "Rekap untuk pelaporan, unduh data, unggah data massal, dan pengelolaan data", "📤")
all_ = logic.enrich_all(store.load_all(), thr)
alerts = logic.build_alerts(all_, thr)

t_rekap, t_alert, t_ekspor, t_impor, t_data = st.tabs(["📊 Rekap per Mitra", "⚠️ Semua Peringatan", "⬇️ Ekspor", "⬆️ Impor Massal", "⚙️ Kelola Data"])

with t_rekap:
    ks, pm, pn = all_["kerjasama"], all_["praktik"], all_["penelitian"]
    mitra = sorted(set(ks.mitra) | set(pm.institusi) | set(pn.institusi) - {""})
    if not mitra:
        st.info("Belum ada data.")
    else:
        rows = []
        for m in mitra:
            k, p, n = ks[ks.mitra == m], pm[pm.institusi == m], pn[pn.institusi == m]
            rows.append({"Mitra / Institusi": m, "MoU": int((k.jenis == "MoU").sum()), "PKS": int((k.jenis == "PKS").sum()), "KB": int((k.jenis == "KB").sum()),
                         "Dokumen aktif": int(k.status.isin(["Aktif", "Segera Berakhir"]).sum()),
                         "Berakhir terdekat": k[k.status.isin(["Aktif", "Segera Berakhir"])].tanggal_berakhir.min(),
                         "Kegiatan praktik": len(p), "Total mahasiswa": int(p.jumlah_mahasiswa.sum()), "Penelitian": len(n)})
        rk = pd.DataFrame(rows).sort_values(["Dokumen aktif", "Kegiatan praktik"], ascending=False)
        st.dataframe(rk, hide_index=True, width="stretch", column_config={
            "Berakhir terdekat": st.column_config.DateColumn(format="DD MMM YYYY")})
        st.download_button("Unduh rekap (CSV)", rk.to_csv(index=False).encode("utf-8-sig"), "rekap_per_mitra.csv", "text/csv")

with t_alert:
    if alerts.empty:
        st.success("Tidak ada peringatan aktif.")
    else:
        lv = st.multiselect("Tingkat", ["Tinggi", "Sedang", "Info"], default=["Tinggi", "Sedang", "Info"])
        kt = st.multiselect("Kategori", sorted(alerts.Kategori.unique()), placeholder="Semua kategori")
        v = alerts[alerts.Tingkat.isin(lv)]
        if kt:
            v = v[v.Kategori.isin(kt)]
        v = v.assign(Tingkat=v.Tingkat.map(C.LEVEL_ICON))
        st.dataframe(v, hide_index=True, width="stretch", column_config={
            "Tanggal": st.column_config.DateColumn(format="DD MMM YYYY"), "Uraian": st.column_config.TextColumn(width="large")})

with t_ekspor:
    st.markdown("**Laporan lengkap (Excel)** — berisi sheet Ringkasan, Kerja Sama, Praktik Mahasiswa, Penelitian, Catatan Monitoring, dan Peringatan.")
    st.download_button("📥 Unduh laporan Excel", export.build_workbook(all_, alerts, thr),
                       f"laporan_kerjasama_sdmk_{logic.today():%Y%m%d}.xlsx",
                       "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", type="primary")
    st.markdown("**CSV per tabel**")
    cols = st.columns(4)
    for c, (k, e) in zip(cols, C.ENTITIES.items()):
        c.download_button(e.title, export.display_frame(k, all_[k]).to_csv(index=False).encode("utf-8-sig"), f"{k}.csv", "text/csv", key=f"csv_{k}", width="stretch")

with t_impor:
    st.markdown("Unggah banyak data sekaligus dari Excel/CSV (mis. rekap lama). Unduh templat agar kolomnya sesuai.")
    key = st.selectbox("Jenis data", list(C.ENTITIES), format_func=lambda k: C.ENTITIES[k].title, key="imp_key")
    st.download_button("📄 Unduh templat Excel", export.template(key), f"templat_{key}.xlsx",
                       "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    up = st.file_uploader("Berkas Excel (.xlsx) atau CSV", type=["xlsx", "csv"], key=f"up_{key}")
    if up:
        try:
            df, problems = export.read_import(key, up)
        except Exception as e:  # noqa: BLE001
            st.error(f"Berkas tidak dapat dibaca: {e}")
            st.stop()
        st.markdown(f"**Pratinjau — {len(df)} baris**")
        st.dataframe(df.head(50), hide_index=True, width="stretch")
        for p in problems:
            st.warning(p)
        if st.button(f"Impor {len(df)} baris", type="primary", disabled=bool(problems) or df.empty):
            n = store.bulk_append(key, df)
            ui.flash(f"{n} baris berhasil diimpor ke {C.ENTITIES[key].title}.")
            st.rerun()
        if problems:
            st.caption("Perbaiki masalah di atas pada berkas Anda lalu unggah ulang.")

with t_data:
    st.markdown("**Cadangan** — unduh laporan Excel di tab Ekspor secara berkala sebagai cadangan.")
    st.error("Zona berbahaya: mengosongkan data tidak dapat dibatalkan. Berguna setelah mencoba data contoh.", icon="🛑")
    key = st.selectbox("Tabel yang dikosongkan", list(C.ENTITIES), format_func=lambda k: C.ENTITIES[k].title, key="reset_key")
    ok = st.text_input("Ketik KOSONGKAN untuk konfirmasi", key="reset_confirm")
    if st.button("Kosongkan tabel", disabled=ok.strip() != "KOSONGKAN"):
        store.reset(key)
        ui.flash(f"Tabel {C.ENTITIES[key].title} dikosongkan.")
        st.rerun()
