import streamlit as st

from core import crud, ui

ui.hero("Penelitian", "Pemantauan izin, pelaksanaan, dan penyerahan laporan hasil penelitian", "🔬")
crud.run("penelitian", st.session_state.get("thr", 90))
