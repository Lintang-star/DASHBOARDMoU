import streamlit as st

from core import crud, ui

ui.hero("Praktik Mahasiswa", "Pencatatan permohonan, penempatan, pembimbing, dan kelengkapan administrasi praktik", "🎓")
crud.run("praktik", st.session_state.get("thr", 90))
